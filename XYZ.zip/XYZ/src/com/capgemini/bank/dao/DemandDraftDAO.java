package com.capgemini.bank.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.exception.DemandDraftException;
import com.capgemini.bank.util.DBConnection;



public class DemandDraftDAO implements IDemandDraftDAO 
{
	
	Logger logger=Logger.getRootLogger();
	public DemandDraftDAO()
	{
	PropertyConfigurator.configure("resources//log4j.properties");
	
	}
	

	//------------------------ 1. Bank Application --------------------------
	/*******************************************************************************************************
	 - Function Name with parameters	:	addDraftDetails(DemandDraft demandDraftBean)
	 - Return Type		:	String
	 - Throws			:  	DemandDraftException
	 - Description		:	Adding Demand Draft Details
	 ********************************************************************************************************/

	@SuppressWarnings("resource")
	public String addDraftDetails(DemandDraft demandDraftBean) throws DemandDraftException 
	{
		Connection connection = DataBaseConnection.getInstance().getConnection();	
		
		PreparedStatement preparedStatement=null;		
		ResultSet resultSet = null;
		
		String transaction_id=null;
		
		int queryResult=0;
		try
		{		
			preparedStatement=connection.prepareStatement(QueryMapper.INSERT_QUERY);
			preparedStatement.setString(1,demandDraftBean.getCustomer_Name());			
			preparedStatement.setString(2,demandDraftBean.getIn_Favor_Of());
			preparedStatement.setString(3,demandDraftBean.getPhone_Number());
			preparedStatement.setInt(4,demandDraftBean.getDemanddraft_Amount());
			preparedStatement.setInt(5,demandDraftBean.getDemanddraft_Commission());
			preparedStatement.setString(6,demandDraftBean.getDemanddraft_Description());
			
			queryResult=preparedStatement.executeUpdate();
		
			preparedStatement = connection.prepareStatement(QueryMapper.TRANSID_QUERY_SEQUENCE);
			resultSet=preparedStatement.executeQuery();

			if(resultSet.next())
			{
				transaction_id=resultSet.getString(1);
						
			}
	
			if(queryResult==0)
			{
				logger.error("Insertion failed ");
				throw new DemandDraftException("Inserting Demand Draft details failed ");

			}
			else
			{
				logger.info("Demand Draft details added successfully:");
				return transaction_id;
			}

		}
		catch(SQLException sqlException)
		{
			sqlException.printStackTrace();
			logger.error(sqlException.getMessage());
			throw new DemandDraftException("Tehnical problem occured refer log");
		}

		finally
		{
			try 
			{
				//resultSet.close();
				preparedStatement.close();
				connection.close();
			}
			catch (SQLException sqlException) 
			{
				sqlException.printStackTrace();
				logger.error(sqlException.getMessage());
				throw new DemandDraftException("Error in closing db connection");

			}
		}
		
		
	}

	@Override
	public DemandDraft viewDraftDetails(String transaction_Id) throws DemandDraftException {
		
			
			Connection connection=DataBaseConnection.getInstance().getConnection();
			
			
			PreparedStatement preparedStatement=null;
			ResultSet resultSet = null;
			DemandDraft demandDraftBean=null;
			
			try
			{
				preparedStatement=connection.prepareStatement(QueryMapper.VIEW_DRAFT_DETAILS_QUERY);
				preparedStatement.setString(1,transaction_Id);
				resultSet=preparedStatement.executeQuery();
				
				if(resultSet.next())
				{
					demandDraftBean = new DemandDraft();
					demandDraftBean.setCustomer_Name(resultSet.getString(1));
					demandDraftBean.setIn_Favor_Of(resultSet.getString(2));
					demandDraftBean.setPhone_Number(resultSet.getString(3));
					demandDraftBean.setDate_Of_Transaction(resultSet.getDate(4));
					demandDraftBean.setDemanddraft_Amount(resultSet.getInt(5));
					demandDraftBean.setDemanddraft_Commission(resultSet.getInt(6));
					demandDraftBean.setDemanddraft_Description(resultSet.getString(7));
					
				}
				
				if( demandDraftBean != null)
				{
					logger.info("Record Found Successfully");
					return demandDraftBean;
				}
				else
				{
					logger.info("Record Not Found Successfully");
					return null;
				}
				
			}
			catch(Exception e)
			{
				logger.error(e.getMessage());
				throw new DemandDraftException(e.getMessage());
			}
			finally
			{
				try 
				{
					resultSet.close();
					preparedStatement.close();
					connection.close();
				} 
				catch (SQLException e) 
				{
					logger.error(e.getMessage());
					throw new DemandDraftException("Error in closing db connection");

				}
			}
			
		}
}