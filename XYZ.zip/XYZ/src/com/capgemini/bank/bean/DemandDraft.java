package com.capgemini.bank.bean;

import java.util.Date;

public class DemandDraft {
	
	private String transaction_Id;
	private String customer_Name;
	private String in_Favor_Of;
	private String phone_Number;
	private Date date_Of_Transaction;
	private int demanddraft_Amount;
	private int demanddraft_Commission;
	private String demanddraft_Description;

	
	public String getTransaction_Id() {
		return transaction_Id;
	}
	public void setTransaction_Id(String transaction_Id) {
		this.transaction_Id = transaction_Id;
	}
	public String getCustomer_Name() {
		return customer_Name;
	}
	public void setCustomer_Name(String customer_Name) {
		this.customer_Name = customer_Name;
	}
	public String getIn_Favor_Of() {
		return in_Favor_Of;
	}
	public void setIn_Favor_Of(String in_Favor_Of) {
		this.in_Favor_Of = in_Favor_Of;
	}
	public String getPhone_Number() {
		return phone_Number;
	}
	public void setPhone_Number(String phone_Number) {
		this.phone_Number = phone_Number;
	}
	public Date getDate_Of_Transaction() {
		return date_Of_Transaction;
	}
	public void setDate_Of_Transaction(Date date_Of_Transaction) {
		this.date_Of_Transaction = date_Of_Transaction;
	}
	public int getDemanddraft_Amount() {
		return demanddraft_Amount;
	}
	public void setDemanddraft_Amount(int demanddraft_Amount) {
		this.demanddraft_Amount = demanddraft_Amount;
	}
	public int getDemanddraft_Commission() {
		return demanddraft_Commission;
	}
	public void setDemanddraft_Commission(int demanddraft_Commission) {
		this.demanddraft_Commission = demanddraft_Commission;
	}
	public String getDemanddraft_Description() {
		return demanddraft_Description;
	}
	public void setDemanddraft_Description(String demanddraft_Description) {
		this.demanddraft_Description = demanddraft_Description;
	}

	@Override
	public String toString() {
		return "DemandDraft [transaction_Id=" + transaction_Id + ", customer_Name=" + customer_Name + ", in_Favor_Of="
				+ in_Favor_Of + ", phone_Number=" + phone_Number + ", date_Of_Transaction=" + date_Of_Transaction
				+ ", demanddraft_Amount=" + demanddraft_Amount + ", demanddraft_Commission=" + demanddraft_Commission + ", demanddraft_Description=" + demanddraft_Description
				+ "]";
	}

}