package com.capgemini.bank.ui;

import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.exception.DemandDraftException;
import com.capgemini.bank.service.DemandDraftService;
import com.capgemini.bank.service.IDemandDraftService;

public class Client {

	static Scanner sc = new Scanner(System.in);
	static IDemandDraftService idemandDraftService = null;
	static DemandDraftService demandDraftService = null;
	static Logger logger = Logger.getRootLogger();

	public static void main(String[] args) {
		PropertyConfigurator.configure("resources//log4j.properties");
		DemandDraft demandDraftBean = null;

		String transaction_Id = null;
		int option = 0;

		while (true) {

			// show menu
			System.out.println();
			System.out.println();
			System.out.println("   XYZ Bank   ");
			System.out.println("_______________________________\n");

			System.out.println("1.Enter Demand Draft Details ");
			System.out.println("2.Print Demand Draft");
			System.out.println("3.Exit");
			System.out.println("________________________________");
			System.out.println("Select an option:");
			// accept option

			try {
				option = sc.nextInt();

				switch (option) {

				case 1:

					while (demandDraftBean == null) {
						demandDraftBean = populateDemandDraft();
						// System.out.println(donorBean);
					}

					try {
						demandDraftService = new DemandDraftService();
						transaction_Id = demandDraftService.addDemandDraftDetails(demandDraftBean);

						System.out.println("Your Demand Draft request has been successfully registered along with the  " +   transaction_Id);
			

					} catch (DemandDraftException DemandDraftException) {
						logger.error("exception occured", DemandDraftException);
						System.out.println("ERROR : "
								+ DemandDraftException.getMessage());
					} finally {
						transaction_Id = null;
						demandDraftService = null;
						demandDraftBean = null;
					}

					break;
					
				case 2:

					demandDraftService = new DemandDraftService();

					System.out.println("Enter numeric donor id:");
					transaction_Id = sc.next();

					while (true) {
						if (demandDraftService.validateDraftId(transaction_Id)) {
							break;
						} else {
							System.err
									.println("Please enter numeric transaction id only, try again");
							transaction_Id = sc.next();
						}
					}

					demandDraftBean = getDraftDetails(transaction_Id);

					if (demandDraftBean != null) {
						System.out.println("Customer_name             :"
								+ demandDraftBean.getCustomer_Name());
						System.out.println("In_favor_of          :"
								+ demandDraftBean.getIn_Favor_Of());
						System.out.println("Phone Number     :"
								+ demandDraftBean.getPhone_Number());
						System.out.println("Date_of_transaction       :"
								+ demandDraftBean.getDate_Of_Transaction());
						System.out.println("Amount       :"
								+ (demandDraftBean.getDemanddraft_Amount()+demandDraftBean.getDemanddraft_Commission()));
						System.out.println("Dd_description()  :"
								+ demandDraftBean.getDemanddraft_Description());
					} else {
						System.err
								.println("There are no  details associated with transcation id "
										+ transaction_Id);
					}

					break;
		
		

				case 3:

					System.out.print("Exit Trust Application");
					System.exit(0);
					break;
				default:
					System.out.println("Enter a valid option[1-4]");
				}    // end of switch
			}

			catch (InputMismatchException e) {
				sc.nextLine();
				System.err.println("Please enter a numeric value, try again");
			}

		}// end of while
	}// end of try


	/*
	 * This function will call the service layer method and return the bean
	 * object which is populated by the information of the given transcationId in
	 * parameter
	 */
	private static DemandDraft getDraftDetails(String transaction_id) {
		DemandDraft demandDraftBean = null;
		idemandDraftService = new DemandDraftService();

		try {
			demandDraftBean = idemandDraftService.viewDemandDraftDetails(transaction_id);
		} catch (DemandDraftException demandDraftException) {
			logger.error("exception occured ", demandDraftException);
			System.out.println("ERROR : " + demandDraftException.getMessage());
		}

		idemandDraftService = null;
		return demandDraftBean;
	}

	
	/* * This function - called by main method - returns a validated bean
	 */
	 
	private static DemandDraft populateDemandDraft() {

		// Reading and setting the values for the demanddraftbean
		
		DemandDraft demanddraftbean = new DemandDraft();;

		System.out.println("\n Enter Details");

		System.out.println("Enter customer name: ");
		demanddraftbean.setCustomer_Name(sc.next());

		System.out.println("In favor of: ");
		demanddraftbean.setIn_Favor_Of(sc.next());

		System.out.println("Enter phone number: ");
		demanddraftbean.setPhone_Number(sc.next());
		
		System.out.println("Enter DD amount");
		demanddraftbean.setDemanddraft_Amount(sc.nextInt());
		
		System.out.println("DD Description");
		demanddraftbean.setDemanddraft_Description(sc.next());
		
		demandDraftService = new DemandDraftService();

		try {
			demandDraftService.validateDemandDraft(demanddraftbean);
			return demanddraftbean;
		} catch (DemandDraftException demandDraftException) {
			logger.error("exception occured", demandDraftException);
			System.err.println("Invalid data:");
			System.err.println(demandDraftException.getMessage() + " \n Try again.***...");
			System.exit(0);

		}
		return null;

	}
}

