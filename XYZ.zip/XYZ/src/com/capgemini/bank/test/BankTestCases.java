package com.capgemini.bank.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.dao.DemandDraftDAO;
import com.capgemini.bank.exception.DemandDraftException;





public class BankTestCases {

	
	
	
		 static DemandDraftDAO dao;
		    static DemandDraft demandDraft;
		    
		    
		    @BeforeClass
		    public static void initialize() {
		        dao = new DemandDraftDAO();
		        demandDraft = new DemandDraft();
		    }
		    
		    @Test
		    public void testAddDemandDraftDetails() throws DemandDraftException {

		        assertNotNull(dao.addDraftDetails(demandDraft));
		    }
		    
		    @Ignore
		    @Test
		    public void testAddDemandDraftDetails1() throws DemandDraftException {
		        assertEquals(10001, dao.addDraftDetails(demandDraft));
		    }
		    
		    @Test
		    public void testAddDemandDraftDetails2() throws DemandDraftException {
		    	
		    	
		    	demandDraft.setCustomer_Name("ABC");
		    	demandDraft.setPhone_Number("1234567890");
		    	demandDraft.setDemanddraft_Amount(5500);
		    	demandDraft.setIn_Favor_Of("capgemini");
		    	demandDraft.setDemanddraft_Description("capgemini");
		        assertTrue("Data Inserted successfully",Integer.parseInt(dao.addDraftDetails(demandDraft)) > 10001);

		    }


	}

}
